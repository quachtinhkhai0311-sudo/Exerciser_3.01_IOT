package com.example.demoiot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoiotApplicationTests {

	@Test
	void contextLoads() {
	}

}
